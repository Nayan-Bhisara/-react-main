import { useState } from 'react'
import A from './assets/A'
import B from './assets/B'
import C from './assets/C'

function App() {

  return (
    <>
      <A/>
      <B/>
      <C/>
    </>
  )
}

export default App