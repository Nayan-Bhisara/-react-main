import React from 'react'

const Viewuser = () => {
  return (
    <div align="center">
        Viewuser
    </div>
  )
}

export default Viewuser