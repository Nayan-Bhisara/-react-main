import Crud from "./Crud"

function App() {

  return (
    <>
      <Crud/>
    </>
  )
}

export default App
