import React from 'react'
import Hoc from '../Hoc'

const B = ({no,Decrement}) => {
  return (
    <div align="center">
      <h2>B Component</h2>
      <h3>count :- {no}</h3>
      <button onClick={ () => Decrement()}>-</button>
    </div>
  )
}

export default Hoc(B)
