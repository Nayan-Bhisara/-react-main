import React, { useState } from 'react'

const Hoc = (Item) => {
  const counter = () => {
    const [no,setNo] = useState(0);
    const Increment = () => {
        setNo(no + 1)
    }
    const Decrement = () => {
        setNo(no - 1)
    }
    return(
        <Item no={no} Increment={Increment} Decrement={Decrement}></Item>
    )
  }
  return counter;
}

export default Hoc
