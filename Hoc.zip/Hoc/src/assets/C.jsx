import React from 'react'
import Hoc from '../Hoc'

const C = ({no,Increment}) => {
  return (
    <div align="center">
      <h2>C Component</h2>
      <h3>count :- {no}</h3>
      <button onClick={ () => Increment()}>+</button>
    </div>
  )
}

export default Hoc(C)
