import React, { useRef, useState } from 'react'

function Form() {
  const username = useRef("");
  const userphone = useRef("");
  const [record,setRecord] = useState([]);
  const submit = (event) =>{
    event.preventDefault();
    let name = username.current.value;
    let phone = userphone.current.value;
    if(!name || !phone){
      alert("all are required")
      return false;
    }
    let obj = {
      id : Math.floor(Math.random()*10000),
      name,phone,
    };
    let old = [...record, obj];
    setRecord(old);
    alert("user create")
    username.current.value = ""
    userphone.current.value = ""
  }
  return (
    <>
        <div align="center">
          <h2>Form</h2>
          <form onSubmit={submit}>
            name :- <input type='text' ref={username}/>
            <br></br><br></br>
            phone :- <input type='text' ref={userphone}/>
            <br></br><br></br>
            <input type="submit"/>
          </form>
          <br></br><br></br>
          <h2>view user</h2>
          <table border={1}>
            <thead>
              <tr>
                <td>Srno</td>
                <td>Name</td>
                <td>Phone</td>
              </tr>
            </thead>
            <tbody>
              {
                record.map((item) =>{
                  const {id,name,phone} = item
                  return (
                    <tr key={id}>
                      <td>{id}</td>
                      <td>{name}</td>
                      <td>{phone}</td>
                    </tr>
                  )
                })
              }
            </tbody>
          </table>
        </div>
    </>
  ) 
}

export default Form